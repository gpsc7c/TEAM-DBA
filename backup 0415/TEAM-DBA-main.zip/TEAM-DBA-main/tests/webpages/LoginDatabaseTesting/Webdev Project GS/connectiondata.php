<?php
//NOTE! This is the connection to the database I used for the old project,
    session_start();
    $servername = "localhost";
    $dbname = "project";
    $username = "root";
    $password = "";
?>