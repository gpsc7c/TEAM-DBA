#INSERT INTO scoreboard_dba.users VALUES (0,'test8', 856,'password', '001001001');
INSERT INTO scoreboard_dba.fractions VALUES (255, 0.255, 9999999);