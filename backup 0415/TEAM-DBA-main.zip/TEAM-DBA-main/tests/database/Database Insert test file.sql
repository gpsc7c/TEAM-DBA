#insert test template
#INSERT INTO scoreboard_dba.users VALUES (1,1,'test','password',1, 1, CURRENT_TIMESTAMP());
INSERT INTO fractio3_dba.users VALUES (0,'test', 1, 'password', '001001001');
INSERT INTO fractio3_dba.fractions VALUES (0011100, 0.0011100, 9999999);