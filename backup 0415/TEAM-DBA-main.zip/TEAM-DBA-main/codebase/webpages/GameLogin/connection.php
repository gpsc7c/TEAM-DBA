<?php
    session_start();
    $servername = "localhost";
    $dbname = "project";
    $username = "root";
    $password = "";
?>
